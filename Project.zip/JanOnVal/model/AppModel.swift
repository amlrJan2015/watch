//
//  AppModel.swift
//  JanOnVal
//
//  Created by Andreas Mueller on 26.01.18.
//  Copyright © 2018 Andreas Mueller. All rights reserved.
//

import Foundation

class AppModel {
    var serverUrl = ""
    var selectedDeviceArr = Array<Device>()
    var refreshTime = 2
}
