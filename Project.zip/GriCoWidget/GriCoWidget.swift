//
//  GriCoWidget.swift
//  GriCoWidget
//
//  Created by Andreas M on 25.09.20.
//  Copyright © 2020 Andreas Mueller. All rights reserved.
//

import WidgetKit
import SwiftUI
import Foundation

struct EnergyLoader {
    private static func logC(val: Double, forBase base: Double) -> Double {
        return log(val)/log(base)
    }
    public static func getSiPrefix(_ value: Double) -> (String, Double) {
        var result = ("",value)
        
        let pow10 = round(logC(val: abs(value), forBase: 10.0)*100000)/100000
        
        
        if pow10 >= 3.0 {
            result = ("k", value / 1000.0)
        }
        if pow10 >= 6.0 {
            result = ("M", value / 1000_000.0)
        }
        if pow10 >= 9.0 {
            result = ("G", value / 1000_000_000.0)
        }
        if pow10 >= 12.0 {
            result = ("T", value / 1000_000_000_000.0)
        }
        
        return result
    }
    
    private static func getRequest(_ url : String) -> URLRequest {
        var request = URLRequest(url: URL(string: url)!)
        request.cachePolicy = URLRequest.CachePolicy.reloadIgnoringLocalCacheData
        
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        return request
    }
    
    static func fetch(completion: @escaping (Result<EnergyEntry, Error>) -> Void) {
        
        let deviceId = 185
        let deviceIdPV = 144
        let measurementValue = "ActiveEnergyConsumed"
        let measurementType = "SUM13"
        let measurementValuePV = "ActiveEnergy"
        let measurementTypePV = "SUM13"
        let startToday = "NAMED_Today"
        let endToday = "NAMED_Today"
        let startYesterday = "NAMED_Yesterday"
        let endYesterday = "NAMED_Yesterday"
        
        var dayComponent = DateComponents()
        dayComponent.hour = -24
        let calendar = Calendar.current
        let yesterday = calendar.date(byAdding: dayComponent, to: Date())!
        
        let ns = Int(yesterday.timeIntervalSince1970) * 1000
        let endYesterdayUTC = "UTC_\(ns)"
        
        
        let urlActiveEnergyToday = "http://gridvis-ems.srv:8080/rest/1/projects/EnergieManagementSystem%20Janitza/devices/\(deviceId)/hist/energy/\(measurementValue)/\(measurementType)?start=\(startToday)&end=\(endToday)"
        let urlActiveEnergyYesterday = "http://gridvis-ems.srv:8080/rest/1/projects/EnergieManagementSystem%20Janitza/devices/\(deviceId)/hist/energy/\(measurementValue)/\(measurementType)?start=\(startYesterday)&end=\(endYesterdayUTC)"
        let urlActiveEnergyTodayPV = "http://gridvis-ems.srv:8080/rest/1/projects/EnergieManagementSystem%20Janitza/devices/\(deviceIdPV)/hist/energy/\(measurementValuePV)/\(measurementTypePV)?start=\(startToday)&end=\(endToday)"
        let urlActiveEnergyYesterdayPV = "http://gridvis-ems.srv:8080/rest/1/projects/EnergieManagementSystem%20Janitza/devices/\(deviceIdPV)/hist/energy/\(measurementValuePV)/\(measurementTypePV)?start=\(startYesterday)&end=\(endYesterdayUTC)"
        
        let requestAEToday = getRequest(urlActiveEnergyToday)
        let requestAEYesterday = getRequest(urlActiveEnergyYesterday)
        let requestAETodayPV = getRequest(urlActiveEnergyTodayPV)
        let requestAEYesterdayPV = getRequest(urlActiveEnergyYesterdayPV)
        
        let task = URLSession.shared.dataTask(with: requestAEToday) { (dataToday, response, error) in
            guard error == nil else {
                completion(.failure(error!))
                return
            }
                
            let task = URLSession.shared.dataTask(with: requestAEYesterday) { (dataYesterday, response, error) in
                guard error == nil else {
                    completion(.failure(error!))
                    return
                }
                
                let task = URLSession.shared.dataTask(with: requestAETodayPV) { (dataPVToday, response, error) in
                    guard error == nil else {
                        completion(.failure(error!))
                        return
                    }
                    
                    let task = URLSession.shared.dataTask(with: requestAEYesterdayPV) { (dataPVYesterday, response, error) in
                        guard error == nil else {
                            completion(.failure(error!))
                            return
                        }
                        
                        let energy = getEnergy(fromDataToday: dataToday!, fromDataYesterday: dataYesterday!,
                                               fromPVDataToday: dataPVToday!, fromPVDataYesterday: dataPVYesterday!)
                        completion(.success(energy))
                    }
                    task.resume()
                }
                task.resume()
                
            }
            task.resume()
        }
        task.resume()
    }
    
    static func getEnergy(fromDataToday dataToday: Foundation.Data,
                          fromDataYesterday dataYesterdayday: Foundation.Data,
                          fromPVDataToday pvDataToday: Foundation.Data,
                          fromPVDataYesterday pvDataYesterday: Foundation.Data) -> EnergyEntry {
        let jsonToday = try! JSONSerialization.jsonObject(with: dataToday, options: []) as! [String: Any]
        let jsonYesterday = try! JSONSerialization.jsonObject(with: dataYesterdayday, options: []) as! [String: Any]
        let jsonPVToday = try! JSONSerialization.jsonObject(with: pvDataToday, options: []) as! [String: Any]
        let jsonPVYesterday = try! JSONSerialization.jsonObject(with: pvDataYesterday, options: []) as! [String: Any]
        if let valueToday = jsonToday["energy"] as? Double,
           let valueYesterday = jsonYesterday["energy"] as? Double,
           let valuePVToday = jsonPVToday["energy"] as? Double,
           let valuePVYesterday = jsonPVYesterday["energy"] as? Double
        {
            
            return EnergyEntry(date: Date(),
                               energyValueToday: valueToday,
                               energyValueYesterday: valueYesterday,
                               unitToday: "Wh",
                               unitYesterday: "Wh",
                               pvValueToday: valuePVToday,
                               pvValueYesterday: valuePVYesterday,
                               pvUnitToday: "Wh",
                               pvUnitYesterday: "Wh"
                               )
        }
        
        return EnergyEntry(date: Date(),energyValueToday: Double.nan,
                           energyValueYesterday: Double.nan,
                           unitToday: "", unitYesterday: "",
                           pvValueToday: Double.nan,
                           pvValueYesterday: Double.nan,
                           pvUnitToday: "",
                           pvUnitYesterday: "")
    }
}


struct Provider: TimelineProvider {
    
    func placeholder(in context: Context) -> EnergyEntry {
        EnergyEntry(date: Date(),
                    energyValueToday: 123.45,
                    energyValueYesterday: 999.22,
                    unitToday: "MWh",
                    unitYesterday: "MWh",
                    pvValueToday: 123.45,
                    pvValueYesterday: 234.56,
                    pvUnitToday: "MWh",
                    pvUnitYesterday: "MWh")
    }
    
    func getSnapshot(in context: Context, completion: @escaping (EnergyEntry) -> ()) {
        let date = Date()
        let entry = EnergyEntry(date: date,
                                energyValueToday: 123.45,
                                energyValueYesterday: 999.12,
                                unitToday: "MWh",
                                unitYesterday: "MWh",
                                pvValueToday: 123.45,
                                pvValueYesterday: 234.56,
                                pvUnitToday: "MWh",
                                pvUnitYesterday: "MWh")
        
        completion(entry)
    }
    
    func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        // Create a timeline entry for "now."
        let date = Date()
        
        // Create a date that's 15 minutes in the future.
        let nextUpdateDate = Calendar.current.date(byAdding: .minute, value: 5, to: date)!
        
        
        EnergyLoader.fetch { result in
            let energyValue: EnergyEntry
            if case .success(let fetchedEnergyValue) = result {
                energyValue = fetchedEnergyValue
            } else {
                energyValue = EnergyEntry(date: Date(),
                                          energyValueToday: Double.nan,
                                          energyValueYesterday: Double.nan,
                                          unitToday: "",
                                          unitYesterday: "",
                                          pvValueToday: Double.nan,
                                          pvValueYesterday: Double.nan,
                                          pvUnitToday: "",
                                          pvUnitYesterday: "")
            }
            let entry = EnergyEntry(date: date,
                                    energyValueToday: energyValue.energyValueToday,
                                    energyValueYesterday: energyValue.energyValueYesterday,
                                    unitToday: energyValue.unitToday,
                                    unitYesterday: energyValue.unitYesterday,
                                    pvValueToday: energyValue.pvValueToday,
                                    pvValueYesterday: energyValue.pvValueYesterday,
                                    pvUnitToday: energyValue.pvUnitToday,
                                    pvUnitYesterday: energyValue.pvUnitYesterday
                                    )
            let timeline = Timeline(entries: [entry], policy: .after(nextUpdateDate))
            completion(timeline)
        }
    }
}

struct EnergyEntry: TimelineEntry {
    let date: Date
    let energyValueToday: Double
    let energyValueYesterday: Double
    let unitToday: String
    let unitYesterday: String
    
    let pvValueToday: Double
    let pvValueYesterday: Double
    let pvUnitToday: String
    let pvUnitYesterday: String
    
    public func getScaledValueToday() -> (String, String) {
        let (siPrefix, newValue) = EnergyLoader.getSiPrefix(energyValueToday)
        return (String(format:"%.2f", newValue), siPrefix+unitToday)
    }
    public func getScaledValueYesterday() -> (String, String) {
        let (siPrefix, newValue) = EnergyLoader.getSiPrefix(energyValueYesterday)
        return (String(format:"%.2f", newValue), siPrefix+unitYesterday)
    }
    public func getScaledPVValueToday() -> (String, String) {
        let (siPrefix, newValue) = EnergyLoader.getSiPrefix(pvValueToday)
        return (String(format:"%.2f", newValue), siPrefix+pvUnitToday)
    }
    public func getScaledPVValueYesterday() -> (String, String) {
        let (siPrefix, newValueToday) = EnergyLoader.getSiPrefix(pvValueYesterday)
        return (String(format:"%.2f", newValueToday), siPrefix+pvUnitYesterday)
    }
}

struct GriCoWidgetEntryView : View {
    @Environment(\.widgetFamily) var family: WidgetFamily
    var entry: Provider.Entry
    
    @ViewBuilder
        var body: some View {
            switch family {
            case .systemSmall: GriCoWidgetSmallEnergyView(entry: entry)
            case .systemMedium: GriCoWidgetMediumEnergyPVView(entry: entry)
            default: GriCoWidgetSmallEnergyView(entry: entry)
            }
        }
}

struct GriCoWidgetSmallEnergyView : View {
    var entry: Provider.Entry
        
    var body: some View {
        HStack {
            VStack(alignment: .center, spacing: 12) {
                ZStack {
                    if entry.energyValueToday >= entry.energyValueYesterday {
                        Circle().fill(Color(red: 1.0, green: 0.1, blue: 0.1, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    } else {
                        Circle().fill(Color(red: 0.0, green: 0.8622, blue: 0.0, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    }
                    
                    Text("🔌")
                        .font(.largeTitle)
                        .multilineTextAlignment(.center)
                    
                }
                VStack(alignment: .center) {
                    Text("Today").font(.system(.footnote, design: .monospaced)).bold()
                    HStack{
                        Text(entry.getScaledValueToday().0).font(.system(.title, design: .monospaced)).bold()
                        Text(entry.getScaledValueToday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
                VStack(alignment: .center) {
                    Text("Yesterday").font(.system(.footnote, design: .monospaced))
                    HStack{
                        Text(entry.getScaledValueYesterday().0).font(.system(.body, design: .monospaced)).bold()
                        Text(entry.getScaledValueYesterday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
            }
        }
        .padding()
    }
}

struct GriCoWidgetMediumEnergyPVView : View {
    var entry: Provider.Entry
    
    var body: some View {
        /*Energy*/
        HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 32) {
            VStack(alignment: .center, spacing: 12) {
                ZStack {
                    if entry.energyValueToday >= entry.energyValueYesterday {
                        Circle().fill(Color(red: 1.0, green: 0.1, blue: 0.1, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    } else {
                        Circle().fill(Color(red: 0.0, green: 0.8622, blue: 0.0, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    }
                    
                    Text("🔌")
                        .font(.largeTitle)
                        .multilineTextAlignment(.center)
                    
                }
                VStack(alignment: .center) {
                    Text("Today").font(.system(.footnote, design: .monospaced)).bold()
                    HStack{
                        Text(entry.getScaledValueToday().0).font(.system(.title, design: .monospaced)).bold()
                        Text(entry.getScaledValueToday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
                VStack(alignment: .center) {
                    Text("Yesterday").font(.system(.footnote, design: .monospaced))
                    HStack{
                        Text(entry.getScaledValueYesterday().0).font(.system(.body, design: .monospaced)).bold()
                        Text(entry.getScaledValueYesterday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
                
            }
            /*PV*/
            VStack(alignment: .center, spacing: 12) {
                ZStack {
                    if entry.pvValueToday <= entry.pvValueYesterday {
                        Circle().fill(Color(red: 1.0, green: 0.1, blue: 0.1, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    } else {
                        Circle().fill(Color(red: 0.0, green: 0.8622, blue: 0.0, opacity: 1.0))
                        .frame(maxWidth: 50, maxHeight: 50)
                    }
                    
                    Text("☀️")
                        .font(.largeTitle)
                        .multilineTextAlignment(.center)
                    
                }
                VStack(alignment: .center) {
                    Text("Today").font(.system(.footnote, design: .monospaced))
                    HStack{
                        Text(entry.getScaledPVValueToday().0).font(.system(.title, design: .monospaced)).bold()
                        Text(entry.getScaledPVValueToday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
                VStack(alignment: .center) {
                    Text("Yesterday").font(.system(.footnote, design: .monospaced))
                    HStack{
                        Text(entry.getScaledPVValueYesterday().0).font(.system(.body, design: .monospaced)).bold()
                        Text(entry.getScaledPVValueYesterday().1).font(.system(.footnote, design: .monospaced))
                    }
                }
                
            }
        }
        .padding()
    }
}


@main
struct GriCoWidget: Widget {
    let kind: String = "GriCoWidget"
    
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            GriCoWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("GriCo Widget")
        .description("Janitza GriCo Widget")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct GriCoWidget_Previews: PreviewProvider {
    
    
    static var previews: some View {
        GriCoWidgetSmallEnergyView(entry: EnergyEntry(date: Date(),
                                                energyValueToday: 1123.45,
                                                energyValueYesterday: 999.33,
                                                unitToday: "Wh",
                                                unitYesterday: "Wh",
                                                pvValueToday: 1565.45,
                                                pvValueYesterday: 2234.56,
                                                pvUnitToday: "Wh",
                                                pvUnitYesterday: "Wh"))
            .previewContext(WidgetPreviewContext(family: .systemSmall))
        GriCoWidgetMediumEnergyPVView(entry: EnergyEntry(date: Date(),
                                                         energyValueToday: 123.45,
                                                         energyValueYesterday: 999.33,
                                                         unitToday: "Wh",
                                                         unitYesterday: "Wh",
                                                         pvValueToday: 2232121123.45,
                                                         pvValueYesterday: 322123234.56,
                                                         pvUnitToday: "Wh",
                                                         pvUnitYesterday: "Wh"))
            .previewContext(WidgetPreviewContext(family: .systemMedium))
    }
}
