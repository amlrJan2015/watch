//
//  MeasurementRowType.swift
//  JanOnVal WatchKit Extension
//
//  Created by Andreas Müller on 04.02.18.
//  Copyright © 2018 Andreas Mueller. All rights reserved.
//

import WatchKit

class MeasurementRowType: NSObject {
    @IBOutlet var value: WKInterfaceLabel!
    @IBOutlet var unit: WKInterfaceLabel!    
    @IBOutlet var header: WKInterfaceLabel!
}
