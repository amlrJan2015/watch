//
//  HistMeasurementRowType.swift
//  JanOnVal WatchKit Extension
//
//  Created by Andreas Müller on 21.02.18.
//  Copyright © 2018 Andreas Mueller. All rights reserved.
//

import WatchKit

class HistMeasurementRowType: NSObject {

    @IBOutlet var dateDesc: WKInterfaceLabel!
    @IBOutlet var unit: WKInterfaceLabel!
    @IBOutlet var value: WKInterfaceLabel!
}
